<section id="cta-banner" class="d-flex align-items-center justify-content-center">
  <div class="container text-center py-5">
    <h2 class="text-white mb-4">Ihr Webdesign, Ihre Homepage ist veraltet?</h2>
    <h3 class="text-secondary fw-bold border p-4 rounded-5 shadow display-6 bg-light">Zeit für einen neuen, frischen Look mit WebDesign Alcor!</h3>
    <p class="text-white mb-4 fs-5">Professionelles Webdesign, Logodesign <br>erstklassige Suchmaschinenoptimierung in Wien Liesing - <span class="fw-bold">ALLES INKLUSIVE</span></p>
    <a href="/kontakt.php" class="btn btn-outline" title="Kontaktieren Sie uns für Webdesign, Logodesign und SEO-Dienstleistungen in Wien Liesing">Schreiben Sie uns jetzt</a>
  </div>
</section>
