<div class="fixed-social-buttons">
  <!-- Facebook Button -->
  <a href="https://www.facebook.com/sharer/sharer.php?u=https://www.webdesign-alcor.at&t=Schau%20dir%20diese%20tolle%20Website%20an!" target="_blank" class="social-btn facebook">
    <i class="bi bi-facebook"></i>
  </a>

  <!-- Instagram Button -->
  <a href="https://www.instagram.com/your_instagram_profile" target="_blank" class="social-btn instagram">
    <i class="bi bi-instagram"></i>
  </a>

  <!-- LinkedIn Button -->
  <a href="https://www.linkedin.com/shareArticle?mini=true&url=https://www.webdesign-alcor.at&title=Webdesign%20Alcor&summary=Professionelles%20Webdesign%20und%20SEO%20in%20Wien" target="_blank" class="social-btn linkedin">
    <i class="bi bi-linkedin"></i>
  </a>

  <!-- WhatsApp Button -->
  <a href="https://wa.me/?text=Schau%20dir%20diese%20tolle%20Website%20an!%20https://www.webdesign-alcor.at" target="_blank" class="social-btn whatsapp">
    <i class="bi bi-whatsapp"></i>
  </a>

  <!-- Telegram Button -->
  <a href="https://telegram.me/share/url?url=https://www.webdesign-alcor.at&text=Schau%20dir%20diese%20tolle%20Website%20an!" target="_blank" class="social-btn telegram">
    <i class="bi bi-telegram"></i>
  </a>

  <!-- Viber Button -->
  <a href="viber://forward?text=Schau%20dir%20diese%20tolle%20Website%20an!%20https://www.webdesign-alcor.at" target="_blank" class="social-btn viber">
    <i class="bi bi-chat-dots"></i>
  </a>

  <!-- Gmail Button -->
  <a href="https://mail.google.com/mail/?view=cm&to=&su=Schau%20dir%20diese%20tolle%20Website%20an!&body=https://www.webdesign-alcor.at" target="_blank" class="social-btn gmail">
    <i class="bi bi-envelope"></i>
  </a>

  <!-- Mail Button -->
  <a href="mailto:?subject=Schau%20dir%20diese%20tolle%20Website%20an!&body=https://www.webdesign-alcor.at" class="social-btn mail">
    <i class="bi bi-envelope-fill"></i>
  </a>
</div>
